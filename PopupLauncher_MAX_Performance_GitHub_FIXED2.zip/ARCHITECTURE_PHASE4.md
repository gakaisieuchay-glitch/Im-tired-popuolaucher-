# Popup Launcher — Phase 4 Architecture & Build Hardening

## Mục tiêu

Phase 4 không thêm framework nặng. Các thay đổi tập trung vào 4 việc có giá trị trực tiếp:

1. Freeform launch dùng đường privileged Root → Shizuku; native fallback chỉ dùng API SDK công khai.
2. Bounds dùng screen-space pixels từ WindowMetrics + system bars/cutout/waterfall insets.
3. Panel có coroutine scope riêng; đóng panel là hủy toàn bộ app enumeration/search/icon jobs.
4. GitHub Actions không phụ thuộc `gradle-wrapper.jar`, vì source archive hiện tại không chứa wrapper JAR.

## Freeform launch contract

`ActivityOptions.setLaunchBounds(Rect)` là public từ API 24. Android framework ghi rõ bounds được tính bằng pixel, screen coordinates; bounds bị bỏ qua nếu thiết bị/display không hỗ trợ `FEATURE_FREEFORM_WINDOW_MANAGEMENT` hoặc PiP.

Do đó:

- Native fallback: `Intent + ActivityOptions.setLaunchBounds()`.
- Root/Shizuku: `am start -n package/activity --windowingMode 5`.
- Không tham chiếu `setLaunchWindowingMode()` hoặc `launchWindowingMode`; đây là API hidden/system và không phải SDK contract ổn định cho app thường.

Nguồn:
- https://developer.android.com/reference/android/app/ActivityOptions
- https://android.googlesource.com/platform/frameworks/base/+/HEAD/core/java/android/app/ActivityOptions.java

## OEM compatibility

Không coi việc ghi `settings put global enable_freeform_support` là "bypass phổ quát".

OEM có thể thay đổi hoặc vô hiệu hoá policy của ActivityTaskManager/WindowManager. Vì vậy launch engine chỉ báo success khi privileged command thực sự trả exit code thành công; nếu freeform bị framework/OEM từ chối, native fallback hạ cấp về activity launch bình thường.

Không sửa `/vendor/etc/permissions` từ app. Đó là can thiệp image/vendor-level, không phải cơ chế runtime portable.

## Bounds & safe area

`OverlayBoundsCalculator` dùng:

- `WindowManager.currentWindowMetrics.bounds` (API 30+)
- `WindowInsets.Type.systemBars()`
- `WindowInsets.Type.displayCutout()`
- `WindowInsets.Type.waterfall()`

Preset vẫn được định nghĩa bằng dp để dễ cấu hình; chỉ chuyển sang px ở ranh giới cuối cùng. Rect truyền tới launch engine là absolute screen-space pixels.

Android 15 + targetSdk 35 enforce edge-to-edge cho Activity UI, nên ứng dụng không được giả định rằng phần top/bottom của display là vùng nội dung an toàn.

Nguồn:
- https://developer.android.com/develop/ui/views/layout/edge-to-edge
- https://developer.android.com/guide/practices/device-compatibility-mode
- https://developer.android.com/develop/ui/compose/system/insets

## Shizuku lifecycle

`ShizukuManager` giữ một UserService connection ngắn hạn:

- `pingBinder()` + permission check trước khi dùng.
- một `UserServiceArgs` có `tag` ổn định.
- bind timeout 3.5 s.
- pool connection tối đa 8 s idle.
- `OnBinderDeadListener` xóa remote binder reference.
- permission callback dùng `addRequestPermissionResultListener`.
- destroy/remove listener khi manager bị hủy.

Mọi shell-side work chạy ngoài Main thread. Mục tiêu latency sub-10 ms được hiểu là warm-path IPC overhead, không phải bảo đảm end-to-end `am start` <10 ms trên mọi ROM; process scheduling, ATMS policy, cold start và I/O có thể vượt ngưỡng này.

Nguồn:
- https://github.com/RikkaApps/Shizuku-API

## Root path

`RootManager` có session `su` warm trong 8 s và fallback one-shot khi session chết/timeout. Root capability (`id -> uid=0`) được cache 5 s để không lặp lại một IPC kiểm tra mỗi lần người dùng chạm app.

Command input từ package/activity được giới hạn bằng regex trước khi đưa vào shell.

## Rendering

Không giữ Hardware Layer khi idle.

Trong drag:

- bắt đầu layer khi vượt drag threshold;
- cập nhật vị trí window qua `WindowManager.updateViewLayout()`;
- thiết lập exclusion rect nhỏ đúng bằng bubble khi cần;
- kết thúc/cancel drag thì bỏ exclusion;
- kết thúc snap animation mới tắt hardware layer.

Lưu ý kiến trúc: với một overlay window, việc thay đổi `LayoutParams.x/y` là thay đổi vị trí cửa sổ ở WindowManager/SurfaceFlinger path; Hardware Layer không phải phép màu giảm toàn bộ compositor work. Vì vậy layer được xem là tối ưu có điều kiện, không phải trạng thái thường trực.

## Panel memory lifecycle

Panel có `panelScope` độc lập nhưng có parent là service job.

Đóng panel:

- cancel panelScope;
- cancel app enumeration/search;
- cancel async icon loads;
- detach TextWatcher;
- detach RecyclerView adapter/layoutManager;
- clear adapter references;
- remove root view khỏi WindowManager;
- clear app list.

Điều này ngăn coroutine icon chạy muộn giữ View/Service sau khi panel đã biến mất.

## Icon cache

Cache là `LruCache` có giới hạn theo KB:

- BitmapDrawable tính theo `bitmap.byteCount`.
- Drawable khác dùng chi phí nhỏ cố định.
- `evictAll()` trên low-memory.
- cache field volatile + lazy init dưới synchronized.

## Foreground Service / Android 14+

Service dùng:

```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
```

và:

```xml
android:foregroundServiceType="specialUse"

<property
    android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
    android:value="popup_game_launcher_overlay" />
```

Đây là type hợp lệ cho use case foreground không thuộc các type chuyên biệt, nhưng việc sử dụng `specialUse` vẫn cần mô tả use case và có thể chịu policy review.

Nguồn:
- https://developer.android.com/develop/background-work/services/fgs/service-types
- https://developer.android.com/about/versions/14/behavior-changes-14

## Quick Settings Tile

Tile chỉ là điều khiển nhanh. Nó không giữ state store thứ hai; state đọc từ `FloatingService.isRunning`.

Không thêm polling timer.

## GitHub build

`.github/workflows/main.yml`:

- Checkout
- JDK 17
- Gradle 8.9
- tự nhận project ở repository root hoặc giải nén một ZIP Android project duy nhất nếu Gradle files không nằm ở root
- validate file quan trọng
- kiểm tra `minSdk=24`, `targetSdk=35`, R8/shrink resources, FGS specialUse
- lint
- unit tests
- compile
- `assembleDebug`
- `assembleRelease`

Debug artifact là APK dễ cài thử. Release artifact được minify/shrink nhưng **không được ký production** khi repository chưa có signing config/secrets.

## Các giới hạn cần giữ nguyên

Không thể bảo đảm freeform trên mọi OEM chỉ bằng code ứng dụng. Một ROM có thể:

- bỏ `FEATURE_FREEFORM_WINDOW_MANAGEMENT`;
- nhận `am start --windowingMode 5` nhưng chuyển task về fullscreen;
- cho phép launch nhưng từ chối resize;
- áp policy riêng trong ActivityTaskManager;
- giết foreground/overlay service theo OEM battery policy.

App phải coi các trường hợp này là compatibility outcomes, không phải crash conditions.

## CI acceptance criteria

Một commit được xem là đạt Phase 4 khi GitHub Actions:

- `lintDebug` pass;
- `testDebugUnitTest` pass;
- `compileDebugKotlin` pass;
- `assembleDebug` pass;
- `assembleRelease` pass;
- hai artifact APK xuất hiện.

On-device validation nên đo: cold/warm launch time, frame pacing khi drag, RSS/PSS idle, panel-open peak memory, icon-cache hit rate, binder reconnect latency, và tỷ lệ freeform success theo ROM/version.
