# PopupLauncher V3 — Phase 1 (Data layer & search)

Đây là **Phase 1 trong nhiều phase**, không phải bản dựng đầy đủ toàn bộ spec
"V3 Ultimate". Lý do tách phase và những điểm cần cân nhắc được ghi rõ bên dưới.

## Đã làm trong Phase 1

Đúng 3 mục trong spec gốc áp dụng trực tiếp cho kiến trúc hiện tại của app
(Service vẽ overlay bằng code, không Activity/Fragment, không file layout XML):

1. **Room Database** (`db/AppUsageEntity.kt`, `AppUsageDao.kt`, `AppUsageDatabase.kt`)
   — thay bộ đếm `SharedPreferences` cũ (`usage_count_<package>`) bằng bảng
   `app_usage`. Có migration 1 lần từ dữ liệu cũ, không mất lịch sử "app dùng
   nhiều nhất" của người dùng đang có.
2. **Advanced Search Engine** (`search/VietnameseSearch.kt`) — bỏ dấu tiếng
   Việt (kể cả "đ", không tự bỏ dấu qua `Normalizer` như các chữ có dấu khác),
   khớp theo tên đầy đủ / chữ cái đầu (initials) / package name. Debounce
   250ms qua coroutine trong `FloatingService.buildSearchBox()`.
3. **High-Speed Icon Caching** (`cache/IconCache.kt`) — `LruCache` trong bộ
   nhớ, cache-hit thì trả ngay (đồng bộ), cache-miss thì tải nền qua
   `Dispatchers.IO` rồi mới cập nhật `ImageView`. `AppListAdapter` tag Job vào
   từng row để hủy load cũ khi RecyclerView tái sử dụng view (tránh nạp nhầm
   icon cho app khác khi cuộn nhanh).

Kèm theo: `showPanel()` không còn gọi `PackageManager` đồng bộ trên main
thread khi người dùng chạm mở bảng chọn — bảng hiện ra ngay với ô tìm kiếm,
phần Ghim nhanh + danh sách app tự điền vào sau khi tải xong ở nền. Đây là
điểm giật/lag thật sự đáng chú ý nhất trên máy yếu (Samsung A12 / Mali GPU)
trong toàn bộ codebase cũ.

Gradle: thêm `kotlinx-coroutines-android`, `androidx.room` (runtime + ktx),
KSP cho Room compiler. Không đổi `minSdk`/`targetSdk`/AGP/Kotlin version.

**Chưa build/compile được trong sandbox này** (không có Android SDK, không có
mạng để tải Gradle/AGP/dependencies) — code đã được rà tay kỹ (import, kiểu
dữ liệu, cân bằng ngoặc) nhưng cần chạy qua `.github/workflows/build_apk.yml`
sẵn có của repo (hoặc Android Studio) để xác nhận build thật trước khi dùng.

## Vì sao KHÔNG làm hết spec "V3 Ultimate" trong 1 lần

Bản spec gốc mô tả một app Android doanh nghiệp tổng hợp (Clean Architecture
nhiều module, Jetpack Compose, Material You + blur, Coil, LeakCanary, ML Kit
OCR, WebView trình duyệt nhúng, AppWidgetHost, Baseline Profiles...) — đây là
khối lượng công việc nhiều tuần của một nhóm thật, và một số mục **mâu thuẫn
trực tiếp** với mục tiêu gốc + hồ sơ của bạn (tối ưu cho máy yếu, Mali GPU):

- **APK < 3MB** trong khi cùng lúc yêu cầu Compose + Room + Coil + Shizuku +
  LeakCanary + ML Kit OCR + WebView-based mini browser: không khả thi cùng
  lúc. Riêng ML Kit text-recognition model đã nặng hơn ngân sách 3MB đó.
- **RenderEffect blur + Material You** hoạt động tốt trên GPU mạnh, nhưng
  đúng loại hiệu ứng dễ gây giật nhất trên Mali GPU đời thấp — ngược mục tiêu
  "tối ưu cho máy yếu" đang ghi rõ trong README của chính app này.
- **MVVM/ViewModel**: UI thật của app nằm trong `FloatingService` (overlay),
  không phải Activity/Fragment — `ViewModel` không gắn vòng đời tự nhiên vào
  Service. Áp dụng máy móc sẽ tạo ra lớp trừu tượng không có tác dụng thật;
  Phase 1 dùng `CoroutineScope` gắn trực tiếp vòng đời Service, đạt cùng mục
  tiêu (reactive, off-main-thread) mà không cần ViewModel giả.
- **LeakCanary trong bản release**: chỉ nên là debug-only dependency.

## Đề xuất các phase tiếp theo

- **Phase 2 — Execution Engine**: coroutine hóa `RootManager` / `ShizukuManager`
  / `ShellCommandService`, pool sẵn 1 shell session thay vì gọi `su`/bind lại
  Shizuku UserService mỗi lần mở app (đúng mục 6.3 trong spec: tránh
  `Runtime.exec("su")` lặp lại). Rủi ro cao nhất trong toàn bộ spec vì đụng
  trực tiếp vào 3 tầng Priority Launch Engine đang chạy thật.
- **Phase 3 — Tiện ích vừa sức với máy yếu**: QS Tile bật/tắt Floating
  Service, biometric lock cho app nhạy cảm, tự ẩn bubble khi vào game/camera
  toàn màn hình, Backup/Restore JSON. Không cần Compose/Coil để làm các mục
  này.
- **Phase 4 (cân nhắc kỹ, không mặc định làm)**: Compose + Material You +
  blur, OCR, mini browser, AppWidgetHost — nên làm sau cùng và có bật/tắt
  runtime, để máy yếu vẫn dùng được bản tối giản.

Muốn mình bắt đầu Phase 2 (Execution Engine) tiếp theo, hay ưu tiên phase
khác trước?
