# Popup Game Launcher — V3 Phase 2

Ứng dụng Android (Kotlin) cho phép bật bất kỳ app nào khác dưới dạng cửa sổ Pop-up
(Freeform Window) ngay trên nền game, tối ưu cho thiết bị cấu hình thấp (Samsung A12 / Mali GPU).

## Tính năng chính (V2)

- **Priority Launch Engine**: Root (`su -c am start`) → Shizuku (UserService quyền shell,
  không cần Root) → `ActivityOptions` (fallback, luôn khả dụng từ Android 7.0/API 24 trở lên).
- **Window Size Presets**: 3 tỷ lệ cửa sổ cố định — Dạng dọc (360×640dp), Vuông (500×500dp),
  Dạng rộng (800×450dp) — quy đổi ra px theo màn hình thật, canh giữa màn hình. Áp dụng thật
  ở cả 3 tầng (Root/Shizuku qua `am task resize`, fallback qua `ActivityOptions.setLaunchBounds`).
- **Per-App Layout Memory**: mỗi app tự nhớ preset kích thước đã chọn lần trước, không cần chọn lại.
- **Quick Pinned Bar**: ghim tối đa 4 app để mở 1 chạm; danh sách app còn lại tự sắp theo
  số lần sử dụng, app dùng nhiều nhất luôn nổi lên đầu.
- **Smart Auto-Fade & Edge Snapping**: bubble tự hít mép màn hình khi thả tay; sau 3 giây
  không chạm trong lúc chơi game, tự mờ còn 25% opacity.
- **Double-Tap Hide**: double-tap vào bubble để thu nhỏ thành đường vạch mỏng dính mép màn
  hình; chạm lại để mở rộng.
- **Memory Saver**: bảng chọn app chỉ được dựng (inflate) khi mở ra và bị gỡ hoàn toàn
  (không chỉ ẩn) khi đóng lại, kèm hủy UserService của Shizuku, giữ RAM/CPU ở mức tối thiểu
  khi ở trạng thái Idle.

## Cấu trúc dự án

```
PopupLauncher_Project/
├── build.gradle.kts                    # Cấu hình Gradle cấp Project
├── settings.gradle.kts                 # Khai báo module + repository
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── .github/workflows/build_apk.yml     # CI: tự động build APK khi push
└── app/
    ├── build.gradle.kts                # Cấu hình Gradle cấp App
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── aidl/com/example/popuplauncher/IShellCommandService.aidl
        ├── java/com/example/popuplauncher/
        │   ├── PopupLauncherApplication.kt
        │   ├── MainActivity.kt
        │   ├── FloatingService.kt       # Bubble + Panel + Double-Tap Hide + Auto-Fade
        │   ├── RootManager.kt           # Priority #1: su -c am start / am task resize
        │   ├── ShizukuManager.kt        # Priority #2/#3: Shizuku UserService + fallback
        │   ├── ShellCommandService.kt   # UserService chạy dưới quyền shell của Shizuku
        │   ├── AppListHelper.kt         # Favorites, usage count, Per-App Layout Memory
        │   ├── AppListAdapter.kt
        │   └── WindowSizePreset.kt      # 3 preset dp + quy đổi bounds theo màn hình thật
        └── res/ (values, drawable, mipmap)
```

## Chuẩn bị trước khi build

1. Cài **Android Studio** (Ladybug trở lên) hoặc dùng terminal với JDK 17 + Android SDK 35 đã cài sẵn.
2. Vì kho mã nguồn này KHÔNG đính kèm file nhị phân `gradle-wrapper.jar`, hãy tạo lại Gradle Wrapper
   một lần duy nhất (yêu cầu máy đã cài Gradle, hoặc dùng Android Studio để tự đồng bộ):

   ```bash
   gradle wrapper --gradle-version 8.9
   ```

   Sau bước này, thư mục sẽ có đầy đủ `gradlew`, `gradlew.bat` và `gradle-wrapper.jar` để build offline.

## Build APK bằng Terminal

Sau khi đã có Gradle Wrapper (bước trên) hoặc nếu máy đã cài Gradle toàn cục:

```bash
# Cấp quyền thực thi cho wrapper (chỉ cần làm 1 lần trên macOS/Linux)
chmod +x ./gradlew

# Build bản Debug (cài thử nhanh, chưa tối ưu ProGuard)
./gradlew assembleDebug

# Build bản Release (đã bật minify/shrink, cần ký APK trước khi cài trên máy thật)
./gradlew assembleRelease
```

Nếu máy đã có Gradle 8.9 sẵn, có thể build trực tiếp bằng:

```bash
gradle assembleDebug
gradle assembleRelease
```

File APK kết quả nằm tại:
`app/build/outputs/apk/debug/app-debug.apk`
`app/build/outputs/apk/release/app-release-unsigned.apk`

## Lưu ý quan trọng

- **Shizuku**: người dùng cuối cần cài & khởi động **Shizuku Manager** (qua Wireless Debugging/ADB
  hoặc Root) rồi cấp quyền trong app thì tính năng mở Pop-up mượt mà (không cần Root) mới hoạt động.
  Nếu không có Shizuku, app tự động dùng cơ chế `ActivityOptions` chuẩn của Android để fallback.
- **Window Bounds**: việc resize kích thước cửa sổ Pop-up theo preset (Dạng dọc/Vuông/Dạng rộng)
  qua lệnh `am task resize` đã được triển khai đầy đủ ở cả 2 nhánh Root và Shizuku (dò `taskId`
  qua `dumpsys activity activities` rồi resize), nhưng vẫn là thao tác *best-effort* — một số
  ROM/OEM có thể chặn hoặc đổi định dạng dumpsys khiến bước resize thất bại; khi đó Pop-up vẫn mở
  Freeform bình thường, chỉ là giữ kích thước mặc định của hệ thống. Nhánh fallback
  (`ActivityOptions.setLaunchBounds`) không phụ thuộc dumpsys nên luôn áp dụng bounds chính xác.
- **Theme fix**: `themes.xml` trước đây kế thừa `Theme.MaterialComponents...` dù dependency
  Material Components đã bị gỡ khỏi `app/build.gradle.kts` ở lần audit trước — lỗi build thật sự
  (Resource Linking Failed). Đã đổi sang `Theme.AppCompat.DayNight.NoActionBar`. Xem chi tiết ở
  `OPTIMIZATION_AUDIT.md`.
- **CI/CD**: workflow GitHub Actions dùng `gradle/actions/setup-gradle` để tự động tải Gradle,
  không cần commit file `gradle-wrapper.jar` nhị phân vào repo.
- **Môi trường tạo ra bản V2 này không có Gradle/Android SDK/mạng internet** để chạy thật
  `./gradlew assembleDebug`. Toàn bộ thay đổi đã được rà soát thủ công kỹ lưỡng (chữ ký hàm khớp
  AIDL, cú pháp `am`/`dumpsys` đã tra cứu lại), nhưng vẫn nên build thử trên máy có Android
  Studio/Gradle trước khi cài lên thiết bị thật — xem mục "Build limitation" trong
  `OPTIMIZATION_AUDIT.md` để biết danh sách kiểm thử khuyến nghị.


## GitHub APK build

Use `.github/workflows/main.yml`. It provisions JDK 17 and Gradle 8.9 directly, runs lint/unit tests,
then builds both `assembleDebug` and minified/shrunk `assembleRelease` artifacts. The workflow intentionally
does not require `gradle-wrapper.jar`; this project archive originally did not contain that binary.

The **debug APK** is the immediately installable artifact. The release APK is minified/shrunk but remains
unsigned unless a signing configuration is added to the repository.

## Freeform compatibility

The native fallback deliberately uses only the public `ActivityOptions.setLaunchBounds(Rect)` API.
The hidden/system `setLaunchWindowingMode()` API is not referenced by application code, because it is
not a stable public SDK contract. Root/Shizuku privileged paths use the shell `am start --windowingMode 5`
route when the device/OEM permits it. If the OEM/framework disables freeform, the native fallback safely
degrades to the normal activity launch.

## Performance design

The bubble uses one delayed fade callback rather than a periodic polling loop; drag updates are direct
WindowManager position updates; panel-owned coroutines (including icon loads) are cancelled as a group;
the icon cache has a small memory-aware budget; and root capability checks are cached briefly to avoid
repeated `id` IPC calls.

The GitHub workflow also accepts a single Android-project `.zip` in the repository when Gradle files are not at repository root; it extracts the ZIP, validates the project, and publishes debug/release APK artifacts.
