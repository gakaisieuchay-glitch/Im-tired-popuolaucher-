# PopupLauncher Performance Audit & Optimization — V2

## Bug thật đã phát hiện và sửa trong đợt audit này

- **`themes.xml` kế thừa `Theme.MaterialComponents.DayNight.NoActionBar` nhưng
  `app/build.gradle.kts` KHÔNG có dependency `com.google.android.material:material`**
  (đã bị gỡ ở lần audit trước để giữ app tối giản). Đây là lỗi build thật sự
  ("Resource linking failed... style not found"), không phải lỗi runtime.
  Đã đổi parent theme sang `Theme.AppCompat.DayNight.NoActionBar` (đã có sẵn qua
  `androidx.appcompat`, `MainActivity` cũng đang kế thừa `AppCompatActivity`), giữ
  nguyên toàn bộ item `colorPrimary/colorPrimaryDark/colorAccent` vì các attr này
  do chính AppCompat khai báo, không phụ thuộc Material Components.

## Nâng cấp mới trong V2 (theo đúng yêu cầu Priority Launch Engine + tiện ích Pop-up)

### 1) Window Size Presets — 3 preset đúng theo yêu cầu, có bounds thật
- `WindowSizePreset` đổi từ 3 preset theo % màn hình (Nhỏ/Vừa/Dọc) sang đúng 3 preset
  theo dp tuyệt đối: **Dạng dọc 360×640dp, Vuông 500×500dp, Dạng rộng 800×450dp**.
- `WindowSizePreset.computeBoundsPx()` quy đổi dp → px theo density thật của máy,
  coerce về không vượt quá kích thước màn hình thật, và canh giữa màn hình.
- Rect bounds này được truyền xuống cả 3 tầng của Priority Launch Engine.

### 2) Áp dụng bounds thật cho cả Root và Shizuku (trước đây bị bỏ ngỏ)
- Trước đây: tham số `sizePreset` được truyền vào `ShizukuManager.launchPopup()`
  nhưng **không hề được dùng để resize cửa sổ thật** — chỉ có comment "best-effort"
  mà không có code tương ứng.
- Nay: sau `am start --windowingMode 5`, cả `RootManager` (chạy qua `su -c`) và
  `ShellCommandService` (chạy trong UserService quyền shell của Shizuku) đều:
  1. Dò `taskId` vừa tạo bằng cách parse `dumpsys activity activities`
     (tìm `#<taskId> A=<package>`), có thử lại tối đa 4 lần / cách nhau 150ms vì
     Activity có thể chưa kịp xuất hiện trong dumpsys ngay lập tức.
  2. Gọi `am task resize <taskId> <left,top,right,bottom>` (đúng cú pháp AOSP:
     4 giá trị cách nhau bằng dấu phẩy, KHÔNG phải 4 tham số tách rời).
- Vẫn giữ đúng bản chất **best-effort** như ghi chú gốc: một số ROM/OEM có thể chặn
  hoặc đổi định dạng dumpsys — khi đó Pop-up vẫn mở Freeform bình thường, chỉ là giữ
  kích thước mặc định hệ thống thay vì đúng preset.
- Tầng fallback (`ActivityOptions`) dùng thẳng `setLaunchBounds(Rect)` (API 24+,
  luôn đáng tin cậy vì chạy trong tiến trình app, không cần parse text).
- AIDL có thêm `launchFreeformPopup(...)` gộp cả bước "am start" + "resize" trong
  1 lượt gọi Binder duy nhất (giảm round-trip IPC so với gọi `execCommand` nhiều lần).

### 3) Per-App Layout Memory
- `AppListHelper` lưu preset đã dùng riêng cho từng package (`SharedPreferences`,
  key `app_preset_<package>`, giá trị là `WindowSizePreset.name`).
- Mỗi lần mở Pop-up: dùng preset đã lưu cho app đó nếu có, ngược lại dùng preset
  đang chọn ở hàng Window Size Presets — VÀ lưu lại lựa chọn đó cho lần sau.
- ProGuard rule mới bảo vệ tên hằng số enum `WindowSizePreset` (đọc/ghi qua
  `valueOf(String)`), tránh R8 đổi tên làm "quên" Per-App Layout Memory đã lưu.

### 4) Quick Pinned Bar (đã có sẵn khung, nay bổ sung usage-based sort)
- Ghim thủ công tối đa 4 app (long-press, giữ nguyên logic FIFO khi đầy) — không đổi.
- MỚI: `AppListHelper.recordAppLaunched()` tăng bộ đếm mỗi lần mở app; danh sách
  chính (`getLaunchableApps()`) tự sắp app dùng nhiều nhất lên đầu (sau các app đã
  ghim), giúp "app dùng nhiều nhất" luôn nổi lên đầu danh sách kể cả khi chưa ghim.
- Panel giờ hiển thị tiêu đề "Ghim nhanh" phía trên Quick Pinned Bar (trước đây
  string resource này tồn tại nhưng không được dùng ở đâu).

### 5) Double-Tap Hide (tính năng mới)
- Double-tap vào nút nổi → thu nhỏ thành đường vạch mỏng 6dp dính sát mép màn hình
  gần nhất (giữ nguyên chiều cao 56dp, chỉ thu hẹp chiều rộng).
- Chạm lại vào đường vạch → mở rộng về kích thước bình thường.
- Nếu double-tap trong lúc bảng chọn đang mở, bảng chọn tự đóng theo (Memory Saver).
- **Đánh đổi kỹ thuật cần lưu ý**: để phân biệt chính xác 1-tap và double-tap mà
  không xung đột, việc mở bảng chọn bằng 1-tap nay có độ trễ nhỏ bằng đúng
  double-tap timeout mặc định của hệ thống (thường ~300-400ms) — đây là đánh đổi
  tiêu chuẩn, không thể tránh khỏi, của mọi UI Android hỗ trợ song song cả tap và
  double-tap trên cùng 1 view (`GestureDetector`).

### 6) Auto-Fade
- Alpha khi mờ đổi từ 0.3 → **0.25 (25%)** đúng theo yêu cầu.
- Auto-fade bị bỏ qua khi bubble đang ở trạng thái thu gọn (Double-Tap Hide) vì
  đường vạch mỏng đã đủ ít gây cản trở, không cần mờ thêm.

## Static compatibility checks (giữ nguyên từ audit trước, vẫn đúng)

- `FloatingService` uses `TYPE_APPLICATION_OVERLAY` on API 26+ and `TYPE_PHONE` below that.
- Native freeform fallback is available from API 24 through `ActivityOptions.launchWindowingMode`
  and `ActivityOptions.setLaunchBounds(Rect)`.
- `specialUse` is declared only as a service type; runtime FGS promotion is passed on API 34+.
- No BOOT_COMPLETED receiver is declared, so Android 15 background FGS boot restrictions are not
  triggered by this app's current flow.
- `am task resize` cú pháp bounds đã được xác minh: `<TASK_ID> <LEFT,TOP,RIGHT,BOTTOM>`
  (1 tham số duy nhất, các giá trị cách nhau bằng dấu phẩy — KHÔNG phải 4 tham số rời).

## Build limitation in this environment

M�i trường thực thi này không có Gradle/Android SDK đã cài sẵn và không có quyền
truy cập mạng để tải về (`services.gradle.org`, `dl.google.com`, `jitpack.io`...),
nên KHÔNG thể chạy `./gradlew assembleDebug`/`assembleRelease` thật ở đây để biên
dịch/verify bằng trình biên dịch Kotlin + R8 thật. Toàn bộ mã nguồn đã được rà soát
thủ công (cấu trúc block, import, chữ ký hàm khớp AIDL, cú pháp `am`/`dumpsys` đã
tra cứu lại) nhưng NÊN build thật trên máy có Android Studio/Gradle trước khi cài
lên thiết bị thật.

Khuyến nghị kiểm thử:
`./gradlew :app:assembleDebug :app:assembleRelease`

Sau đó test trên:
- Android 7/8 cho khả năng tương thích overlay.
- Android 13/14 cho hành vi notification + FGS.
- Android 15 (target 35) cho hành vi FGS/background-start.
- Máy đã Root (Magisk/Superuser) — kiểm tra cả nhánh resize qua `su`.
- Máy không Root nhưng có Shizuku — kiểm tra cả nhánh resize qua UserService.
- Máy không Root/không Shizuku — chỉ còn `ActivityOptions.setLaunchBounds` fallback.
- Thử cả 3 Window Size Presets, xác nhận Per-App Layout Memory nhớ đúng theo từng app
  sau khi tắt/mở lại nút nổi.
- Thử double-tap nút nổi nhiều lần liên tiếp để xác nhận không bị "kẹt" ở trạng thái
  thu gọn/mở rộng khi thao tác nhanh.

## Phase 2 — Execution Engine Optimization (implemented)

### RootManager

- `hasRootAccess()` and `launchFreeform()` are now `suspend` APIs backed by `Dispatchers.IO`.
- `applyBoundsBestEffort()` uses coroutine `delay()` instead of `Thread.sleep()`.
- SU process stdout/stderr is drained concurrently with `waitFor()` so a busy `dumpsys` response cannot deadlock on a full pipe.
- Child processes are terminated on timeout and the output collector is cancelled.

### ShizukuManager

- Removed the permanent `ExecutorService` / `newSingleThreadExecutor()` thread.
- Added a lifecycle-bound `SupervisorJob + Dispatchers.IO` scope and a `Mutex` around the complete priority launch transaction.
- UserService binding is exposed to the launch coroutine through a cancellable continuation; the old nested callback -> executor -> Binder call chain is gone.
- Root -> Shizuku -> native fallback remains asynchronous from the caller's perspective.
- Only the final framework `startActivity()` operation is switched to the main dispatcher; all privileged process/Binder waiting remains off-main.

### ShellCommandService

- Removed executors completely.
- Added lifecycle-bound IO coroutine scope.
- Preserved the AIDL method signatures for compatibility; the synchronous Binder API uses a small `runBlocking` bridge while child process I/O executes on `Dispatchers.IO`.
- `Thread.sleep()` is replaced with `delay()` in task lookup.

### FloatingService

No call-site update is required because `ShizukuManager.launchPopup(...)` keeps its original parameter list. The existing call already behaves as fire-and-forget.
