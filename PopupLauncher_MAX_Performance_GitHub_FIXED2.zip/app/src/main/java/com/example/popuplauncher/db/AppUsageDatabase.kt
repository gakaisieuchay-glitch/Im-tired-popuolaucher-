package com.example.popuplauncher.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AppUsageEntity::class], version = 1, exportSchema = false)
abstract class AppUsageDatabase : RoomDatabase() {

    abstract fun appUsageDao(): AppUsageDao

    companion object {
        @Volatile
        private var instance: AppUsageDatabase? = null

        fun getInstance(context: Context): AppUsageDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppUsageDatabase::class.java,
                    "app_usage.db"
                )
                    // No shipped migrations yet (version 1). If the schema ever changes,
                    // add a real Migration instead of this before releasing V3.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
