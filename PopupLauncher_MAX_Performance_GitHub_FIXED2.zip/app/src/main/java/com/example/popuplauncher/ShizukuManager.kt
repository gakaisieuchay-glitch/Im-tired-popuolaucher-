package com.example.popuplauncher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

/**
 * Single gateway for all Shizuku work.
 *
 * Policy:
 *  - Root is checked/used first by [RootManager] (fastest privileged path).
 *  - Shizuku is used second through one short-lived UserService connection.
 *  - Native ActivityOptions is the final fallback.
 *
 * The UserService connection is pooled for a few seconds so repeated launches do not pay the
 * Binder/service startup cost every time, while an idle timeout releases it to keep RAM low.
 */
object ShizukuManager {

    private const val TAG = "ShizukuManager"
    private const val PERMISSION_REQUEST_CODE = 1001
    private const val USER_SERVICE_VERSION = 1
    private const val IDLE_UNBIND_MS = 8_000L
    private const val BIND_TIMEOUT_MS = 3_500L
    private const val WINDOWING_MODE_FREEFORM = 5

    private val stateLock = Any()
    private val launchMutex = Mutex()
    private val managerJob = SupervisorJob()
    private val scope = CoroutineScope(managerJob + Dispatchers.IO)

    private var appContext: Context? = null
    private var userServiceArgs: Shizuku.UserServiceArgs? = null
    private var userServiceConnection: ServiceConnection? = null
    private var shellService: IShellCommandService? = null
    private var idleUnbindJob: Job? = null
    private var destroyed = false

    private var permissionResultListener: PermissionResultListener? = null
    private var initialized = false

    // Stable Shizuku permission callback; Shizuku owns this callback, not Android's
    // Activity#onRequestPermissionsResult() mechanism.
    private val permissionResultListenerBridge =
        object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                if (requestCode != PERMISSION_REQUEST_CODE) return
                permissionResultListener?.onPermissionResult(
                    grantResult == PackageManager.PERMISSION_GRANTED
                )
            }
        }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        synchronized(stateLock) {
            destroyed = false
        }
        Log.d(TAG, "Shizuku binder received")
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        synchronized(stateLock) {
            shellService = null
        }
        cancelIdleUnbind()
        Log.w(TAG, "Shizuku binder died")
    }

    interface PermissionResultListener {
        fun onPermissionResult(granted: Boolean)
    }

    fun initialize(context: Context) {
        val contextApp = context.applicationContext
        synchronized(stateLock) {
            appContext = contextApp
            if (destroyed || initialized) return
            initialized = true
        }

        runCatching { Shizuku.addBinderReceivedListenerSticky(binderReceivedListener) }
        runCatching { Shizuku.addBinderDeadListener(binderDeadListener) }
        runCatching { Shizuku.addRequestPermissionResultListener(permissionResultListenerBridge) }
    }

    fun isShizukuAvailable(): Boolean =
        runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun hasShizukuPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    fun requestShizukuPermission() {
        if (!isShizukuAvailable() || hasShizukuPermission()) return
        runCatching { Shizuku.requestPermission(PERMISSION_REQUEST_CODE) }
            .onFailure { Log.e(TAG, "Không thể yêu cầu quyền Shizuku", it) }
    }

    fun setPermissionResultListener(listener: PermissionResultListener?) {
        permissionResultListener = listener
    }

    /** Call from MainActivity when Shizuku returns a permission result. */
    fun dispatchPermissionResult(requestCode: Int, granted: Boolean) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            permissionResultListener?.onPermissionResult(granted)
        }
    }

    /**
     * Warm the Shizuku UserService while the launcher panel is open.
     * The first actual launch can then avoid the bind handshake on the critical tap path.
     */
    fun prewarm(context: Context): Job = scope.launch {
        if (!hasShizukuPermission()) return@launch
        val service = bindUserServiceIfNeeded(context.applicationContext)
        if (service != null) scheduleIdleUnbind()
    }

    /**
     * Root -> Shizuku -> Native fallback.
     * Returns a Job owned by this manager so callers can cancel their launch work if needed.
     */
    fun launchPopup(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect? = null
    ): Job {
        val contextApp = context.applicationContext
        synchronized(stateLock) {
            appContext = contextApp
            destroyed = false
        }

        return scope.launch {
            launchMutex.withLock {
                if (RootManager.hasRootAccess() &&
                    RootManager.launchFreeform(targetPackage, targetActivity, bounds)
                ) {
                    return@withLock
                }

                if (hasShizukuPermission() &&
                    launchViaShizuku(contextApp, targetPackage, targetActivity, bounds)
                ) {
                    return@withLock
                }

                launchViaNativeFallback(contextApp, targetPackage, targetActivity, bounds)
            }
        }
    }

    /** Compatibility alias for callers that use the Phase-2 name. */
    suspend fun <T> runWithService(block: suspend () -> T): Result<T> =
        withShellService(appContext ?: return Result.failure(IllegalStateException("ShizukuManager chưa được initialize"))) {
            block()
        }?.let { Result.success(it) }
            ?: Result.failure(IllegalStateException("Shizuku service unavailable or permission denied"))

    /** Execute a privileged operation through the pooled Shizuku UserService. */
    suspend fun <T> withShellService(
        context: Context,
        block: suspend (IShellCommandService) -> T
    ): T? {
        if (!hasShizukuPermission()) return null
        val contextApp = context.applicationContext
        synchronized(stateLock) { appContext = contextApp; destroyed = false }

        return launchMutex.withLock {
            val service = bindUserServiceIfNeeded(contextApp) ?: return@withLock null
            try {
                block(service)
            } finally {
                scheduleIdleUnbind()
            }
        }
    }

    private suspend fun launchViaShizuku(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect?
    ): Boolean {
        val service = bindUserServiceIfNeeded(context) ?: return false

        return try {
            val left = bounds?.left ?: 0
            val top = bounds?.top ?: 0
            val right = bounds?.right ?: 0
            val bottom = bounds?.bottom ?: 0

            val exitCode = withContext(Dispatchers.IO) {
                service.launchFreeformPopup(
                    targetPackage,
                    targetActivity,
                    left,
                    top,
                    right,
                    bottom
                )
            }
            Log.d(TAG, "Shizuku launch exitCode=$exitCode component=$targetPackage/$targetActivity")
            exitCode == 0
        } catch (t: Throwable) {
            Log.e(TAG, "Shizuku launch thất bại", t)
            false
        } finally {
            scheduleIdleUnbind()
        }
    }

    private suspend fun bindUserServiceIfNeeded(context: Context): IShellCommandService? {
        synchronized(stateLock) {
            shellService?.let { return it }
        }

        if (!isShizukuAvailable() || !hasShizukuPermission()) return null

        return withTimeoutOrNull(BIND_TIMEOUT_MS) {
            suspendCancellableCoroutine { continuation ->
                val completed = AtomicBoolean(false)
                lateinit var args: Shizuku.UserServiceArgs

                val connection = object : ServiceConnection {
                    override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                        val api = service?.let(IShellCommandService.Stub::asInterface)
                        if (api == null || !continuation.isActive || !completed.compareAndSet(false, true)) {
                            if (api != null) {
                                runCatching { Shizuku.unbindUserService(args, this, true) }
                            }
                            return
                        }
                        synchronized(stateLock) {
                            shellService = api
                            userServiceConnection = this
                        }
                        continuation.resume(api)
                    }

                    override fun onServiceDisconnected(name: ComponentName?) {
                        synchronized(stateLock) {
                            if (userServiceConnection === this) {
                                userServiceConnection = null
                                shellService = null
                            }
                        }
                    }
                }

                args = buildUserServiceArgs(context)
                synchronized(stateLock) { userServiceConnection = connection }

                val bound = runCatching {
                    Shizuku.bindUserService(args, connection)
                }.isSuccess

                if (!bound) {
                    completed.set(true)
                    synchronized(stateLock) {
                        if (userServiceConnection === connection) {
                            userServiceConnection = null
                            shellService = null
                        }
                    }
                    if (continuation.isActive) continuation.resume(null)
                    return@suspendCancellableCoroutine
                }

                continuation.invokeOnCancellation {
                    completed.set(true)
                    runCatching { Shizuku.unbindUserService(args, connection, true) }
                    synchronized(stateLock) {
                        if (userServiceConnection === connection) {
                            userServiceConnection = null
                            shellService = null
                        }
                    }
                }
            }
        }
    }

    private fun buildUserServiceArgs(context: Context): Shizuku.UserServiceArgs {
        synchronized(stateLock) {
            userServiceArgs?.let { return it }
            val args = Shizuku.UserServiceArgs(
                ComponentName(context, ShellCommandService::class.java)
            )
                .daemon(false)
                .tag("popup-launcher-shell-v1")
                .processNameSuffix("popup")
                .debuggable(false)
                .version(USER_SERVICE_VERSION)
            userServiceArgs = args
            return args
        }
    }

    private fun scheduleIdleUnbind() {
        idleUnbindJob?.cancel()
        idleUnbindJob = scope.launch {
            delay(IDLE_UNBIND_MS)
            unbindUserService()
        }
    }

    fun unbindUserService() {
        idleUnbindJob?.cancel()
        idleUnbindJob = null

        val (args, connection) = synchronized(stateLock) {
            userServiceArgs to userServiceConnection
        }

        if (args != null && connection != null) {
            runCatching { Shizuku.unbindUserService(args, connection, true) }
                .onFailure { Log.w(TAG, "unbindUserService thất bại: ${it.message}") }
        }

        synchronized(stateLock) {
            shellService = null
            userServiceConnection = null
        }
    }

    private suspend fun launchViaNativeFallback(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect?
    ) {
        val intent = Intent().apply {
            component = ComponentName(targetPackage, targetActivity)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        }

        // launchWindowingMode is a hidden/system API. A normal app must not reference it.
        // The supported public path is setLaunchBounds(); the framework honors the bounds
        // on displays that support freeform/PiP, otherwise it safely ignores them.
        val options = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
            bounds != null && bounds.width() > 0 && bounds.height() > 0
        ) {
            ActivityOptions.makeBasic().setLaunchBounds(Rect(bounds))
        } else {
            null
        }

        withContext(Dispatchers.Main.immediate) {
            runCatching {
                if (options != null) {
                    context.startActivity(intent, options.toBundle())
                } else {
                    context.startActivity(intent)
                }
            }.recoverCatching {
                context.startActivity(
                    Intent().apply {
                        component = ComponentName(targetPackage, targetActivity)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.onFailure {
                Log.e(TAG, "Native fallback cũng thất bại: ${it.message}", it)
            }
        }
    }

    fun destroy() {
        synchronized(stateLock) {
            destroyed = true
            permissionResultListener = null
        }
        cancelIdleUnbind()
        unbindUserService()
        runCatching { Shizuku.removeBinderReceivedListener(binderReceivedListener) }
        runCatching { Shizuku.removeBinderDeadListener(binderDeadListener) }
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionResultListenerBridge) }
        managerJob.cancel()
    }

    private fun cancelIdleUnbind() {
        idleUnbindJob?.cancel()
        idleUnbindJob = null
    }
}
