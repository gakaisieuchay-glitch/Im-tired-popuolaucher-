package com.example.popuplauncher

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.content.res.Configuration
import android.provider.Settings
import android.graphics.PixelFormat
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.popuplauncher.cache.IconCache
import com.example.popuplauncher.utils.OverlayBoundsCalculator
import com.example.popuplauncher.utils.OverlayRenderOptimizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * FloatingService - Foreground Service quản lý:
 *  - Nút nổi (Floating Bubble): kéo thả tự do + tự động hít mép màn hình (Edge Snapping).
 *  - Auto-Fade: sau 3 giây không chạm, giảm Opacity còn 25% để không che tầm nhìn trong game.
 *  - Double-Tap Hide: double-tap vào nút nổi để thu nhỏ nó thành 1 đường vạch mỏng dính
 *    sát mép màn hình; chạm lại vào đường vạch đó để mở rộng về kích thước bình thường.
 *  - Bảng chọn app (Popup Panel): Quick Search Bar + Quick Pinned Bar (ghim tối đa 4 app,
 *    danh sách chính tự sắp app dùng nhiều nhất lên đầu) + danh sách toàn bộ app.
 *  - Window Size Presets + Per-App Layout Memory: mỗi app tự nhớ tỷ lệ cửa sổ Pop-up
 *    riêng đã chọn lần trước, áp dụng lại tự động ở lần mở tiếp theo.
 *  - Memory Saver: khi thu gọn bảng chọn, GỠ HẲN view khỏi WindowManager (không chỉ ẩn),
 *    dừng hoàn toàn việc vẽ giao diện (Idle UI State) để giải phóng CPU/RAM cho Game.
 *
 * Mục tiêu hiệu năng: RAM của service này khi ở trạng thái Idle (chỉ có bubble) phải < 25MB,
 * và CPU ~ 0% khi bubble đứng yên (không có animation/timer nào chạy ngầm liên tục).
 *
 * Lưu ý về Double-Tap Hide: để phân biệt chính xác 1-tap (mở bảng chọn) với double-tap
 * (thu gọn/mở rộng) mà không xung đột lẫn nhau, việc mở bảng chọn bằng 1-tap sẽ có độ trễ
 * rất nhỏ (bằng đúng double-tap timeout mặc định của hệ thống, thường ~300-400ms) trước khi
 * kích hoạt - đây là đánh đổi bắt buộc, tiêu chuẩn của mọi UI Android khi hỗ trợ song song
 * cả tap và double-tap trên cùng 1 view (GestureDetector).
 */
class FloatingService : Service() {

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "popup_launcher_channel"
        private const val NOTIFICATION_ID = 101
        private const val AUTO_FADE_DELAY_MS = 3000L
        private const val FADE_ALPHA = 0.25f
        private const val FULL_ALPHA = 1.0f
        private const val CLICK_DRAG_THRESHOLD_PX = 12
        private const val BUBBLE_SIZE_DP = 56
        private const val COLLAPSED_WIDTH_DP = 6
        private const val SEARCH_DEBOUNCE_MS = 250L

        const val ACTION_START = "com.example.popuplauncher.action.START"
        const val ACTION_STOP = "com.example.popuplauncher.action.STOP"

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var appListHelper: AppListHelper

    // Tied to the Service's lifecycle (cancelled in onDestroy), not to the panel's —
    // individual in-flight jobs (search, app-list load) are tracked and cancelled
    // separately whenever the panel itself is closed, see removePanel().
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loadAppsJob: Job? = null
    private var searchJob: Job? = null
    private var panelScope: CoroutineScope? = null

    // ----- Bubble -----
    private var bubbleView: ImageView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private val fadeHandler = Handler(Looper.getMainLooper())
    private var isBubbleAdded = false
    private var isBubbleCollapsed = false
    private var edgeAnimator: ValueAnimator? = null
    private var bubbleGestureDetector: GestureDetector? = null

    // ----- Panel (bảng chọn app) -----
    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var isPanelAdded = false
    private var appAdapter: AppListAdapter? = null
    private var panelRecyclerView: RecyclerView? = null
    private var searchBox: EditText? = null
    private var searchTextWatcher: TextWatcher? = null
    private var allApps: List<AppEntry> = emptyList()
    private var selectedSizePreset: WindowSizePreset = WindowSizePreset.DEFAULT

    // Biến tạm cho thao tác kéo-thả
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var initialViewX = 0
    private var initialViewY = 0
    private var isDragging = false
    private var dragFramePosted = false
    private var pendingDragX = 0
    private var pendingDragY = 0
    private val dragFrameRunnable = Runnable {
        dragFramePosted = false
        val view = bubbleView ?: return@Runnable
        val params = bubbleParams ?: return@Runnable
        if (!isDragging || !isBubbleAdded) return@Runnable
        params.x = pendingDragX
        params.y = pendingDragY
        safeUpdateViewLayout(view, params)
    }

    private val autoFadeRunnable = Runnable {
        if (!isBubbleCollapsed) {
            bubbleView?.animate()?.alpha(FADE_ALPHA)?.setDuration(250)?.start()
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        // Helper uses applicationContext internally, so it never retains this Service.
        appListHelper = AppListHelper(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                try {
                    val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    } else {
                        0
                    }
                    ServiceCompat.startForeground(
                        this,
                        NOTIFICATION_ID,
                        buildNotification(),
                        fgsType
                    )
                    showBubble()
                } catch (e: SecurityException) {
                    // Do not crash the process if an OEM blocks the FGS promotion.
                    // The visible overlay remains independently guarded by SYSTEM_ALERT_WINDOW.
                    Log.e("FloatingService", "Không thể promote Foreground Service: ${e.message}", e)
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bubbleView?.post { clampBubbleToSafeArea() }
    }

    override fun onDestroy() {
        isRunning = false
        serviceScope.cancel()
        fadeHandler.removeCallbacksAndMessages(null)
        fadeHandler.removeCallbacks(dragFrameRunnable)
        dragFramePosted = false
        edgeAnimator?.cancel()
        edgeAnimator = null
        bubbleView?.animate()?.cancel()
        removePanel(releaseShellService = true)
        removeBubble()
        super.onDestroy()
    }

    // -------------------------------------------------------------------
    // Notification (bắt buộc để Foreground Service không bị hệ thống kill)
    // -------------------------------------------------------------------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.floating_service_label),
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): android.app.Notification {
        val stopIntent = Intent(this, FloatingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_add)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.floating_service_label))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.btn_stop_service), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    // -------------------------------------------------------------------
    // BUBBLE: tạo, kéo-thả, edge-snap, auto-fade, double-tap hide
    // -------------------------------------------------------------------

    private fun getOverlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showBubble() {
        if (isBubbleAdded) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Log.w("FloatingService", "Overlay permission không còn hợp lệ; stopping service.")
            stopSelf()
            return
        }

        val bubble = ImageView(this).apply {
            setImageResource(android.R.drawable.sym_def_app_icon)
            setBackgroundResource(R.drawable.bubble_background)
            val density = resources.displayMetrics.density
            val paddingPx = (8 * density).toInt()
            setPadding(paddingPx, paddingPx, paddingPx, paddingPx)
            alpha = FULL_ALPHA
        }

        val density = resources.displayMetrics.density
        val bubbleSizePx = (BUBBLE_SIZE_DP * density).toInt()

        val params = WindowManager.LayoutParams(
            bubbleSizePx,
            bubbleSizePx,
            getOverlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = resources.displayMetrics.heightPixels / 3
        }

        bubbleGestureDetector = GestureDetector(this, BubbleGestureListener())
        bubble.setOnTouchListener { view, event -> handleBubbleTouch(view, event) }

        try {
            windowManager.addView(bubble, params)
        } catch (t: Throwable) {
            Log.e("FloatingService", "Không thể thêm overlay bubble", t)
            return
        }
        bubbleView = bubble
        bubbleParams = params
        isBubbleAdded = true
        isBubbleCollapsed = false

        scheduleAutoFade()
    }

    private fun removeBubble() {
        cancelAutoFade()
        edgeAnimator?.cancel()
        edgeAnimator = null
        bubbleView?.animate()?.cancel()

        val view = bubbleView
        if (view != null) {
            OverlayRenderOptimizer.disableHardwareLayer(view)
            runCatching { windowManager.removeViewImmediate(view) }
        }
        bubbleView = null
        bubbleParams = null
        bubbleGestureDetector = null
        isBubbleAdded = false
        isBubbleCollapsed = false
    }

    /**
     * GestureDetector chỉ lo phân biệt 1-tap (mở bảng chọn / mở rộng bubble) với
     * double-tap (thu gọn/mở rộng bubble). Việc kéo-thả (drag) vẫn do
     * [handleBubbleTouch] tự quản lý bằng [isDragging], độc lập với detector này -
     * cả 2 callback dưới đây đều bỏ qua nếu [isDragging] đang true để tránh trường hợp
     * vừa kéo-thả vừa bị tính nhầm thành tap.
     */
    private inner class BubbleGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (isDragging) return false
            if (isBubbleCollapsed) {
                expandBubble()
            } else {
                togglePanel()
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (isDragging) return false
            toggleBubbleCollapsed()
            return true
        }
    }

    /**
     * Xử lý chạm cho nút nổi:
     *  - Mọi sự kiện đều được đưa qua [bubbleGestureDetector] trước để nó tự phân biệt
     *    tap/double-tap (xem [BubbleGestureListener]).
     *  - ACTION_DOWN: lưu vị trí ban đầu, hủy Auto-Fade, trả về alpha đầy đủ.
     *  - ACTION_MOVE: di chuyển bubble theo ngón tay (kéo thả tự do) khi vượt ngưỡng.
     *  - ACTION_UP: nếu đã kéo-thả (isDragging) -> thực hiện Edge Snapping.
     *               Nếu KHÔNG kéo-thả, việc mở bảng chọn / thu gọn / mở rộng bubble
     *               đã được xử lý bởi GestureDetector ở trên.
     */
    private fun handleBubbleTouch(view: View, event: MotionEvent): Boolean {
        val params = bubbleParams ?: return false
        bubbleGestureDetector?.onTouchEvent(event)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                cancelAutoFade()
                edgeAnimator?.cancel()
                edgeAnimator = null
                view.animate().cancel()
                if (view.alpha != FULL_ALPHA) {
                    view.animate().alpha(FULL_ALPHA).setDuration(150).start()
                }
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                initialViewX = params.x
                initialViewY = params.y
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val deltaX = event.rawX - initialTouchX
                val deltaY = event.rawY - initialTouchY

                if (!isDragging &&
                    (abs(deltaX) > CLICK_DRAG_THRESHOLD_PX || abs(deltaY) > CLICK_DRAG_THRESHOLD_PX)
                ) {
                    isDragging = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        view.setSystemGestureExclusionRects(
                            listOf(Rect(0, 0, view.width, view.height))
                        )
                    }
                    OverlayRenderOptimizer.enableHardwareLayer(view)
                }

                if (isDragging) {
                    pendingDragX = (initialViewX + deltaX).toInt()
                    pendingDragY = (initialViewY + deltaY).toInt()
                    if (!dragFramePosted) {
                        dragFramePosted = true
                        view.postOnAnimation(dragFrameRunnable)
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (isDragging) {
                    fadeHandler.removeCallbacks(dragFrameRunnable)
                    dragFramePosted = false
                    params.x = pendingDragX
                    params.y = pendingDragY
                    safeUpdateViewLayout(view, params)
                    snapToNearestEdge(view, params)
                } else {
                    OverlayRenderOptimizer.disableHardwareLayer(view)
                }
                clearGestureExclusion(view)
                isDragging = false
                scheduleAutoFade()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                fadeHandler.removeCallbacks(dragFrameRunnable)
                dragFramePosted = false
                isDragging = false
                clearGestureExclusion(view)
                OverlayRenderOptimizer.disableHardwareLayer(view)
                scheduleAutoFade()
                return true
            }
        }
        return false
    }

    private fun clearGestureExclusion(view: View) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            view.setSystemGestureExclusionRects(emptyList())
        }
    }

    private fun safeUpdateViewLayout(view: View, params: WindowManager.LayoutParams) {
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            // View có thể đã bị remove giữa chừng (ví dụ Service bị dừng đột ngột) -> bỏ qua an toàn.
        }
    }

    private fun clampBubbleToSafeArea() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        val safe = OverlayBoundsCalculator.getSafeArea(windowManager)
        val left = safe.bounds.left + safe.leftInset
        val top = safe.bounds.top + safe.topInset
        val right = (safe.bounds.right - safe.rightInset - view.width).coerceAtLeast(left)
        val bottom = (safe.bounds.bottom - safe.bottomInset - view.height).coerceAtLeast(top)
        params.x = params.x.coerceIn(left, right)
        params.y = params.y.coerceIn(top, bottom)
        safeUpdateViewLayout(view, params)
    }

    /** Edge Snapping: tự động trượt bubble về mép trái hoặc phải gần nhất, có hiệu ứng mượt. */
    private fun snapToNearestEdge(view: View, params: WindowManager.LayoutParams) {
        val safe = OverlayBoundsCalculator.getSafeArea(windowManager)
        val leftEdge = safe.bounds.left + safe.leftInset
        val rightEdge = safe.bounds.right - safe.rightInset
        val bubbleWidth = view.width.takeIf { it > 0 } ?: params.width

        val centerX = params.x + bubbleWidth / 2
        val targetX = if (centerX < (leftEdge + rightEdge) / 2) {
            leftEdge
        } else {
            (rightEdge - bubbleWidth).coerceAtLeast(leftEdge)
        }

        edgeAnimator?.cancel()
        val animator = ValueAnimator.ofInt(params.x, targetX)
        edgeAnimator = animator
        animator.addUpdateListener { animation ->
            params.x = animation.animatedValue as Int
            safeUpdateViewLayout(view, params)
        }
        animator.duration = 220
        animator.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (edgeAnimator === animator) edgeAnimator = null
                OverlayRenderOptimizer.disableHardwareLayer(view)
            }

            override fun onAnimationCancel(animation: android.animation.Animator) {
                if (edgeAnimator === animator) edgeAnimator = null
                OverlayRenderOptimizer.disableHardwareLayer(view)
            }
        })
        animator.start()
    }

    private fun scheduleAutoFade() {
        cancelAutoFade()
        if (!isBubbleCollapsed) {
            fadeHandler.postDelayed(autoFadeRunnable, AUTO_FADE_DELAY_MS)
        }
    }

    private fun cancelAutoFade() {
        fadeHandler.removeCallbacks(autoFadeRunnable)
    }

    private fun toggleBubbleCollapsed() {
        if (isBubbleCollapsed) expandBubble() else collapseBubble()
    }

    /**
     * Double-Tap Hide: thu nhỏ nút nổi thành một đường vạch cực mỏng dính sát mép màn hình
     * gần nhất hiện tại. Nếu bảng chọn app đang mở, đóng luôn bảng chọn cho gọn (Memory Saver).
     */
    private fun collapseBubble() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return

        if (isPanelAdded) {
            removePanel(releaseShellService = true)
        }

        isBubbleCollapsed = true
        cancelAutoFade()
        view.animate().cancel()
        view.alpha = FULL_ALPHA

        val density = resources.displayMetrics.density
        val safe = OverlayBoundsCalculator.getSafeArea(windowManager)
        val leftEdge = safe.bounds.left + safe.leftInset
        val rightEdge = safe.bounds.right - safe.rightInset
        val collapsedWidthPx = (COLLAPSED_WIDTH_DP * density).toInt()
        val isLeftSide = params.x < (leftEdge + rightEdge) / 2

        params.width = collapsedWidthPx
        params.x = if (isLeftSide) {
            leftEdge
        } else {
            (rightEdge - collapsedWidthPx).coerceAtLeast(leftEdge)
        }
        safeUpdateViewLayout(view, params)
    }

    /** Chạm lại vào đường vạch mỏng để mở rộng nút nổi về kích thước bình thường. */
    private fun expandBubble() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return

        isBubbleCollapsed = false
        val density = resources.displayMetrics.density
        val safe = OverlayBoundsCalculator.getSafeArea(windowManager)
        val leftEdge = safe.bounds.left + safe.leftInset
        val rightEdge = safe.bounds.right - safe.rightInset
        val fullSizePx = (BUBBLE_SIZE_DP * density).toInt()
        val isLeftSide = params.x <= (leftEdge + rightEdge) / 2

        params.width = fullSizePx
        params.x = if (isLeftSide) {
            leftEdge
        } else {
            (rightEdge - fullSizePx).coerceAtLeast(leftEdge)
        }
        safeUpdateViewLayout(view, params)
        scheduleAutoFade()
    }

    // -------------------------------------------------------------------
    // PANEL: bảng chọn app, Quick Search Bar, Quick Pinned Bar
    // -------------------------------------------------------------------

    private fun togglePanel() {
        if (isPanelAdded) {
            removePanel(releaseShellService = true)
        } else {
            showPanel()
        }
    }

    /**
     * Memory Saver: bảng chọn CHỈ được dựng (inflate) khi người dùng thật sự mở ra.
     * Toàn bộ view, adapter, danh sách app được giải phóng ngay khi đóng lại.
     */
    private fun showPanel() {
        if (isPanelAdded) return

        val density = resources.displayMetrics.density
        val panelWidthPx = (300 * density).toInt()
        val panelHeightPx = (420 * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.popup_panel_background)
            val paddingPx = (14 * density).toInt()
            setPadding(paddingPx, paddingPx, paddingPx, paddingPx)
        }

        // Only the size-preset row + search box are built synchronously: neither touches
        // PackageManager, so the panel appears on screen immediately on tap.
        container.addView(buildSizePresetRow(density))
        container.addView(buildSearchBox(density))

        val params = WindowManager.LayoutParams(
            panelWidthPx,
            panelHeightPx,
            getOverlayWindowType(),
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleParams?.x ?: 0
            y = (bubbleParams?.y ?: 0) + (64 * density).toInt()
        }

        try {
            windowManager.addView(container, params)
        } catch (t: Throwable) {
            Log.e("FloatingService", "Không thể thêm panel overlay", t)
            panelScope?.cancel()
            panelScope = null
            return
        }
        panelView = container
        panelParams = params
        isPanelAdded = true

        // Hide privileged setup latency behind the app-list enumeration. No polling and no
        // privileged work runs while the panel is merely idle.
        serviceScope.launch(Dispatchers.IO) {
            if (RootManager.hasRootAccess()) {
                RootManager.prewarm()
            } else {
                ShizukuManager.prewarm(applicationContext)
            }
        }

        panelScope = CoroutineScope(
            Dispatchers.Main.immediate +
                SupervisorJob(serviceScope.coroutineContext[Job])
        )

        // Favorites row + main app list depend on the installed-app enumeration, which is
        // the one genuinely slow PackageManager call in this flow — load it off the main
        // thread and fill these two sections in once ready, instead of making the whole
        // panel wait (and the bubble tap feel laggy) on a low-end device.
        val currentPanelScope = panelScope ?: return
        loadAppsJob = currentPanelScope.launch {
            val apps = appListHelper.getLaunchableApps()
            if (!isPanelAdded) return@launch
            allApps = apps
            buildFavoritesSection(density)?.let { container.addView(it, 2) }
            container.addView(buildAppRecyclerView(density))
        }
    }

    /** Đóng bảng chọn: gỡ HẲN view khỏi WindowManager + giải phóng Shizuku UserService (Memory Saver). */
    private fun removePanel(releaseShellService: Boolean) {
        // Cancel every panel-owned coroutine (app enumeration, search debounce, icon loads,
        // favorite icon loads) before tearing down the WindowManager view hierarchy.
        panelScope?.cancel()
        panelScope = null
        loadAppsJob = null
        searchJob = null

        // Detach listeners/adapters before dropping the root view so RecyclerView,
        // TextWatcher and click lambdas cannot retain the Service longer than necessary.
        searchBox?.let { box ->
            searchTextWatcher?.let(box::removeTextChangedListener)
        }
        searchTextWatcher = null
        searchBox = null

        panelRecyclerView?.apply {
            stopScroll()
            adapter = null
            layoutManager = null
        }
        panelRecyclerView = null

        appAdapter?.clearReferences()
        appAdapter = null
        allApps = emptyList()

        panelView?.let { panel ->
            runCatching { windowManager.removeViewImmediate(panel) }
        }
        panelView = null
        panelParams = null
        isPanelAdded = false

        if (releaseShellService) {
            ShizukuManager.unbindUserService()
            // Mirror the release on the Root side too: same "user is clearly done for now"
            // signal that should drop the pooled su session immediately rather than
            // waiting out its own idle timeout.
            RootManager.releaseSession()
        }
    }

    private fun buildSizePresetRow(density: Float): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = WindowSizePreset.entries.size.toFloat()
            val bottomMarginPx = (8 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = bottomMarginPx }
        }

        WindowSizePreset.entries.forEach { preset ->
            val button = TextView(this).apply {
                text = preset.label
                setTextColor(Color.WHITE)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(0, (8 * density).toInt(), 0, (8 * density).toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = (4 * density).toInt()
                }
                setBackgroundResource(R.drawable.search_box_background)
                alpha = if (preset == selectedSizePreset) 1.0f else 0.55f
                setOnClickListener {
                    selectedSizePreset = preset
                    // Cập nhật lại alpha toàn bộ hàng để phản ánh lựa chọn hiện tại
                    for (i in 0 until row.childCount) {
                        row.getChildAt(i).alpha = 0.55f
                    }
                    this.alpha = 1.0f
                }
            }
            row.addView(button)
        }
        return row
    }

    private fun buildSearchBox(density: Float): View {
        val searchBox = EditText(this).apply {
            hint = getString(R.string.search_hint)
            setHintTextColor(Color.parseColor("#88FFFFFF"))
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.search_box_background)
            val paddingH = (12 * density).toInt()
            val paddingV = (8 * density).toInt()
            setPadding(paddingH, paddingV, paddingH, paddingV)
            isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8 * density).toInt() }
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                searchJob?.cancel()
                searchJob = panelScope?.launch {
                    delay(SEARCH_DEBOUNCE_MS)
                    val filtered = withContext(Dispatchers.Default) {
                        appListHelper.filterApps(allApps, query)
                    }
                    appAdapter?.updateData(filtered)
                }
            }

            override fun afterTextChanged(s: Editable?) = Unit
        }

        searchBox.addTextChangedListener(watcher)
        this.searchBox = searchBox
        searchTextWatcher = watcher
        return searchBox
    }

    /**
     * Quick Pinned Bar: hiển thị tối đa 4 app đã được ghim (long-press trong danh sách chính
     * để ghim/bỏ ghim) để kích hoạt Pop-up chỉ với 1 chạm. Trả về null (không thêm section
     * nào vào panel) khi chưa có app nào được ghim, để không chiếm chỗ vô ích.
     */
    private fun buildFavoritesSection(density: Float): View? {
        val favoriteApps = appListHelper.getFavoriteApps(allApps)
        if (favoriteApps.isEmpty()) return null

        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8 * density).toInt() }
        }

        val title = TextView(this).apply {
            text = getString(R.string.favorites_title)
            setTextColor(Color.parseColor("#B0BEC5"))
            textSize = 11f
            setPadding(0, 0, 0, (4 * density).toInt())
        }
        section.addView(title)

        val scrollView = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (52 * density).toInt()
            )
        }

        val favoritesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val iconSizePx = (44 * density).toInt()

        favoriteApps.forEach { entry ->
            val cachedIcon = IconCache.getCached(entry)
            val icon = ImageView(this).apply {
                setImageDrawable(cachedIcon)
                layoutParams = LinearLayout.LayoutParams(iconSizePx, iconSizePx).apply {
                    marginEnd = (10 * density).toInt()
                }
                setOnClickListener {
                    launchAppAsPopup(entry)
                }
            }
            if (cachedIcon == null) {
                panelScope?.launch {
                    icon.setImageDrawable(IconCache.load(applicationContext, entry))
                }
            }
            favoritesContainer.addView(icon)
        }

        scrollView.addView(favoritesContainer)
        section.addView(scrollView)
        return section
    }

    private fun buildAppRecyclerView(density: Float): View {
        val recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@FloatingService)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            itemAnimator = null
            setHasFixedSize(true)
            overScrollMode = View.OVER_SCROLL_NEVER
            setItemViewCacheSize(2)
            recycledViewPool.setMaxRecycledViews(0, 8)
        }

        val adapter = AppListAdapter(
            items = allApps,
            scope = panelScope ?: serviceScope,
            iconLoader = { entry -> IconCache.load(applicationContext, entry) },
            onItemClick = ::launchAppAsPopup,
            onItemLongClick = ::onFavoriteToggled
        )
        recyclerView.adapter = adapter
        panelRecyclerView = recyclerView
        appAdapter = adapter
        return recyclerView
    }

    private fun onFavoriteToggled(entry: AppEntry) {
        appListHelper.toggleFavorite(entry.packageName)
        // Làm mới lại toàn bộ panel để cập nhật hàng Ghim nhanh + badge yêu thích + thứ tự danh sách.
        removePanel(releaseShellService = false)
        showPanel()
    }

    /**
     * Mở app dưới dạng Pop-up:
     *  1) Lấy preset kích thước đã lưu riêng cho app này (Per-App Layout Memory), hoặc
     *     dùng preset đang chọn ở hàng Window Size Presets nếu đây là lần đầu mở app đó.
     *  2) Lưu lại lựa chọn đó cho app (để lần sau tự nhớ), và tăng bộ đếm sử dụng
     *     (phục vụ sắp xếp "app dùng nhiều nhất lên đầu danh sách").
     *  3) Quy đổi preset -> Rect bounds tuyệt đối theo màn hình thật rồi đưa xuống
     *     Priority Launch Engine (Root -> Shizuku -> ActivityOptions).
     */
    private fun launchAppAsPopup(entry: AppEntry) {
        val displayMetrics = resources.displayMetrics
        val preset = appListHelper.getPresetForApp(entry.packageName) ?: selectedSizePreset
        appListHelper.savePresetForApp(entry.packageName, preset)
        // Fire-and-forget: recordAppLaunched is now a suspend Room write and must not
        // block the popup launch itself.
        serviceScope.launch { appListHelper.recordAppLaunched(entry.packageName) }

        val bounds = OverlayBoundsCalculator.centeredDp(
            windowManager = windowManager,
            widthDp = preset.widthDp,
            heightDp = preset.heightDp,
            density = resources.displayMetrics.density
        )

        ShizukuManager.launchPopup(
            context = this,
            targetPackage = entry.packageName,
            targetActivity = entry.activityName,
            bounds = bounds
        )
        // Sau khi mở app dưới dạng Pop-up, tự động thu gọn bảng chọn để nhường không gian cho Game.
        removePanel(releaseShellService = false)
    }
}
