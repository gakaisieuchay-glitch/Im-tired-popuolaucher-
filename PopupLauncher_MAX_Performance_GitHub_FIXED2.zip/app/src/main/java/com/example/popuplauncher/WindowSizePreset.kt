package com.example.popuplauncher

import android.graphics.Rect

/**
 * Danh sách các preset kích thước cửa sổ Pop-up (Freeform Window).
 *
 * Mỗi preset khai báo kích thước "chuẩn" theo dp:
 *  - COMPACT_PHONE (Dạng dọc)  : 360 x 640 dp
 *  - SQUARE        (Dạng vuông): 500 x 500 dp
 *  - LANDSCAPE     (Dạng rộng) : 800 x 450 dp
 *
 * [computeBoundsPx] quy đổi kích thước dp đó sang Rect tuyệt đối theo px, LUÔN được
 * giới hạn (coerce) để không vượt quá kích thước màn hình thật và được canh giữa
 * màn hình. Rect này được truyền thẳng xuống cả 3 tầng mở Pop-up:
 *  1) Root      -> lệnh shell "am task resize <taskId> <left,top,right,bottom>"
 *  2) Shizuku   -> UserService thực thi "am task resize" tương tự, chạy trong
 *                  tiến trình quyền shell do Shizuku cấp.
 *  3) Fallback  -> ActivityOptions.setLaunchBounds(Rect) (API 24+).
 */
enum class WindowSizePreset(
    val label: String,
    val widthDp: Int,
    val heightDp: Int
) {
    COMPACT_PHONE(label = "Dạng dọc", widthDp = 360, heightDp = 640),
    SQUARE(label = "Vuông", widthDp = 500, heightDp = 500),
    LANDSCAPE(label = "Dạng rộng", widthDp = 800, heightDp = 450);

    /**
     * Tính Rect (bounds tuyệt đối theo px) canh giữa màn hình thật.
     *
     * Chiều rộng/cao mong muốn (widthDp/heightDp * density) được coerce về tối đa
     * bằng kích thước màn hình thật để tránh cửa sổ tràn ra ngoài màn hình trên các
     * thiết bị có màn hình nhỏ hơn preset (ví dụ preset Landscape 800dp trên máy
     * có màn hình vật lý hẹp hơn).
     */
    fun computeBoundsPx(screenWidthPx: Int, screenHeightPx: Int, density: Float): Rect {
        val requestedWidthPx = (widthDp * density).toInt()
        val requestedHeightPx = (heightDp * density).toInt()

        val widthPx = requestedWidthPx.coerceIn(1, screenWidthPx.coerceAtLeast(1))
        val heightPx = requestedHeightPx.coerceIn(1, screenHeightPx.coerceAtLeast(1))

        val left = ((screenWidthPx - widthPx) / 2).coerceAtLeast(0)
        val top = ((screenHeightPx - heightPx) / 2).coerceAtLeast(0)

        return Rect(left, top, left + widthPx, top + heightPx)
    }

    companion object {
        /** Preset mặc định khi app chưa có Per-App Layout Memory cho 1 app nào đó. */
        val DEFAULT = SQUARE

        /** Dùng khi đọc lại preset đã lưu cho từng app (Per-App Layout Memory) từ SharedPreferences. */
        fun fromNameSafe(name: String?): WindowSizePreset? {
            if (name.isNullOrBlank()) return null
            return entries.firstOrNull { it.name == name }
        }

        fun fromOrdinalSafe(ordinal: Int): WindowSizePreset {
            return entries.getOrElse(ordinal) { DEFAULT }
        }
    }
}
