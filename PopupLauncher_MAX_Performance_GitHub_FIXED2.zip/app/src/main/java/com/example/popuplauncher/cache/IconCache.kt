package com.example.popuplauncher.cache

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import com.example.popuplauncher.AppEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * In-memory app-icon cache so the RecyclerView never re-resolves (and the
 * PackageManager never re-decodes) a Drawable it already loaded once while
 * scrolling. Item 1 of the V3 spec ("stop fetching raw icons synchronously
 * during UI rendering") — this is the highest-value piece of it for a device
 * like the Samsung A12: `PackageManager.getActivityIcon()` was previously
 * called on the Service's main thread inside `onBindViewHolder`.
 *
 * The cache is byte-budgeted via LruCache.sizeOf(), so large bitmap icons cost more
 * than vector drawables. This keeps the cap meaningful on low-memory phones.
 */
object IconCache {

    @Volatile
    private var cache: LruCache<String, Drawable>? = null

    private fun cacheFor(context: Context): LruCache<String, Drawable> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val activityManager =
                context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memoryClassMb = activityManager?.memoryClass ?: 32
            // Budget roughly 1/32 of the app memory class, capped at 2 MiB. Bitmap-backed
            // icons are charged by their actual byte count; vector/other drawables cost 4 KiB.
            val maxKb = (memoryClassMb * 1024 / 32).coerceIn(256, 2048)
            val newCache = object : LruCache<String, Drawable>(maxKb) {
                override fun sizeOf(key: String, value: Drawable): Int {
                    val kb = if (value is BitmapDrawable) {
                        ((value.bitmap.byteCount + 1023) / 1024).coerceAtLeast(1)
                    } else {
                        4
                    }
                    return kb
                }
            }
            cache = newCache
            return newCache
        }
    }

    private fun keyFor(entry: AppEntry): String = "${entry.packageName}/${entry.activityName}"

    /** Synchronous, non-blocking cache read for the icon's fast path (no coroutine needed). */
    fun getCached(entry: AppEntry): Drawable? = cache?.get(keyFor(entry))

    /**
     * Resolves the icon off the main thread and caches the result.
     * Safe to call repeatedly for the same entry — subsequent calls hit the cache.
     */
    suspend fun load(context: Context, entry: AppEntry): Drawable? {
        val appContext = context.applicationContext
        val memCache = cacheFor(appContext)
        memCache.get(keyFor(entry))?.let { return it }

        return withContext(Dispatchers.IO) {
            val packageManager = appContext.packageManager
            val drawable = runCatching {
                packageManager.getActivityIcon(
                    ComponentName(entry.packageName, entry.activityName)
                )
            }.getOrElse {
                runCatching { packageManager.getApplicationIcon(entry.packageName) }.getOrNull()
            }
            drawable?.also { memCache.put(keyFor(entry), it) }
        }
    }

    /** Call from onTrimMemory or a package-changed broadcast in a later phase. */
    fun clear() {
        cache?.evictAll()
    }
}
