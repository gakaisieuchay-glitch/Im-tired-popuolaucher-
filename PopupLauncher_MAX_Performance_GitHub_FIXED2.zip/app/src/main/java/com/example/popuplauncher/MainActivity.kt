package com.example.popuplauncher

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.popuplauncher.optimization.OptimizationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * MainActivity - Màn hình cấp quyền ban đầu.
 * Giao diện được dựng bằng code (không cần file layout riêng) để giữ app tối giản,
 * đúng tinh thần "Không nhồi thư viện thừa / file thừa" của dự án.
 *
 * Luồng cấp quyền:
 * 1) SYSTEM_ALERT_WINDOW (Overlay)   -> bắt buộc để vẽ nút nổi.
 * 2) Shizuku permission               -> để mở app Pop-up mượt mà, không cần Root.
 * 3) Bấm "Bật nút nổi" -> khởi động FloatingService.
 */
class MainActivity : AppCompatActivity(), ShizukuManager.PermissionResultListener {

    private lateinit var statusOverlayText: TextView
    private lateinit var statusShizukuText: TextView
    private lateinit var startStopButton: Button
    private lateinit var boostSwitch: Switch
    private lateinit var boostLogText: TextView
    private lateinit var optimizationManager: OptimizationManager

    // No lifecycle-runtime-ktx dependency in this project (kept intentionally minimal),
    // so a small Activity-scoped CoroutineScope does the same job as lifecycleScope here.
    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        optimizationManager = OptimizationManager(applicationContext)
        setContentView(buildRootView())
        ShizukuManager.setPermissionResultListener(this)
    }

    override fun onResume() {
        super.onResume()
        refreshStatusUI()
    }

    override fun onDestroy() {
        activityScope.cancel()
        ShizukuManager.setPermissionResultListener(null)
        super.onDestroy()
    }

    override fun onPermissionResult(granted: Boolean) {
        runOnUiThread {
            val message = if (granted) "Đã cấp quyền Shizuku!" else "Bạn đã từ chối quyền Shizuku."
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            refreshStatusUI()
        }
    }

    // -------------------------------------------------------------------
    // UI dựng bằng code
    // -------------------------------------------------------------------

    private fun buildRootView(): android.view.View {
        val density = resources.displayMetrics.density
        val paddingPx = (24 * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(paddingPx, paddingPx, paddingPx, paddingPx)
            setBackgroundColor(Color.parseColor("#121722"))
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, 0, 0, (16 * density).toInt())
        }
        root.addView(title)

        statusOverlayText = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 14f
            setPadding(0, 0, 0, (4 * density).toInt())
        }
        root.addView(statusOverlayText)

        val overlayButton = Button(this).apply {
            text = getString(R.string.btn_grant_overlay)
            setOnClickListener { requestOverlayPermission() }
        }
        root.addView(overlayButton)

        addSpacer(root, density)

        statusShizukuText = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 14f
            setPadding(0, 0, 0, (4 * density).toInt())
        }
        root.addView(statusShizukuText)

        val shizukuButton = Button(this).apply {
            text = getString(R.string.btn_grant_shizuku)
            setOnClickListener { requestShizukuPermission() }
        }
        root.addView(shizukuButton)

        addSpacer(root, density)

        startStopButton = Button(this).apply {
            text = getString(R.string.btn_start_service)
            setOnClickListener { onStartStopClicked() }
        }
        root.addView(startStopButton)

        addSpacer(root, density)

        val boostTitle = TextView(this).apply {
            text = "🚀 Chế độ Siêu Tối Ưu (Super Boost)"
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        root.addView(boostTitle)

        val boostDescription = TextView(this).apply {
            text = "Dọn RAM, thu hồi app nền đang rảnh, khoá tần số quét cao nhất trước khi " +
                "mở Pop-up. Cần quyền Root hoặc Shizuku ở bước 2 (không có thì chỉ dọn được " +
                "cache của riêng app này)."
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        root.addView(boostDescription)

        boostSwitch = Switch(this).apply {
            text = "Bật Super Boost"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, isChecked -> onBoostToggled(isChecked) }
        }
        root.addView(boostSwitch)

        boostLogText = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, (8 * density).toInt(), 0, 0)
        }
        root.addView(boostLogText)

        addSpacer(root, density)

        val note = TextView(this).apply {
            text = "Ghi chú: Shizuku Manager cần được cài đặt và kích hoạt " +
                "(qua ADB Wireless Debugging hoặc Root) trước khi cấp quyền ở bước 2."
            setTextColor(Color.GRAY)
            textSize = 12f
            gravity = Gravity.START
        }
        root.addView(note)

        val scrollView = ScrollView(this)
        scrollView.addView(
            root,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return scrollView
    }

    private fun addSpacer(parent: LinearLayout, density: Float) {
        val spacer = android.view.View(this)
        spacer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (20 * density).toInt()
        )
        parent.addView(spacer)
    }

    // -------------------------------------------------------------------
    // Logic cấp quyền
    // -------------------------------------------------------------------

    private fun hasOverlayPermission(): Boolean {
        return Settings.canDrawOverlays(this)
    }

    private fun requestOverlayPermission() {
        if (hasOverlayPermission()) {
            Toast.makeText(this, "Đã có quyền Overlay.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestShizukuPermission() {
        if (!ShizukuManager.isShizukuAvailable()) {
            Toast.makeText(
                this,
                "Shizuku chưa chạy. Vui lòng cài đặt & khởi động Shizuku Manager trước.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (ShizukuManager.hasShizukuPermission()) {
            Toast.makeText(this, "Đã có quyền Shizuku.", Toast.LENGTH_SHORT).show()
            return
        }
        ShizukuManager.requestShizukuPermission()
    }

    private fun onStartStopClicked() {
        if (!hasOverlayPermission()) {
            Toast.makeText(this, "Vui lòng cấp quyền Overlay trước.", Toast.LENGTH_SHORT).show()
            return
        }

        val isRunning = startStopButton.text == getString(R.string.btn_stop_service)
        val intent = Intent(this, FloatingService::class.java)

        if (isRunning) {
            intent.action = FloatingService.ACTION_STOP
            startService(intent)
            startStopButton.text = getString(R.string.btn_start_service)
        } else {
            intent.action = FloatingService.ACTION_START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            startStopButton.text = getString(R.string.btn_stop_service)
        }
    }

    private fun onBoostToggled(enabled: Boolean) {
        boostSwitch.isEnabled = false
        activityScope.launch {
            if (enabled) {
                val result = optimizationManager.enableSuperBoost()
                boostLogText.text = result.logs.joinToString("\n")
                if (!result.isFullySuccess) {
                    Toast.makeText(
                        this@MainActivity,
                        "Một vài bước Super Boost không thành công — xem log bên dưới.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } else {
                optimizationManager.disableSuperBoost()
                boostLogText.text = "Đã tắt Super Boost, trả lại tần số quét mặc định."
            }
            boostSwitch.isEnabled = true
        }
    }

    private fun refreshStatusUI() {
        statusOverlayText.text = if (hasOverlayPermission()) {
            "✔ Quyền Overlay: Đã cấp"
        } else {
            "✘ Quyền Overlay: Chưa cấp"
        }

        statusShizukuText.text = when {
            !ShizukuManager.isShizukuAvailable() -> "✘ Shizuku: Chưa chạy"
            ShizukuManager.hasShizukuPermission() -> "✔ Shizuku: Đã cấp quyền"
            else -> "△ Shizuku: Đang chạy, chưa cấp quyền"
        }
    }
}
