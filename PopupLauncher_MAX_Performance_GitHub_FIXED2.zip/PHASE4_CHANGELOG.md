# Phase 4 Change Log

- Fixed Shizuku permission callback by adding a stable `OnRequestPermissionResultListener`.
- Removed hidden `ActivityOptions.launchWindowingMode` usage from the normal app process.
- Native fallback now uses public `ActivityOptions.setLaunchBounds()`.
- Added `OverlayBoundsCalculator` using `WindowMetrics`, system-bar, cutout and waterfall insets.
- Bubble snapping/collapse/expand now respects safe horizontal insets.
- Bubble drag temporarily uses hardware layer and selective gesture exclusion; layer is released after snap.
- Panel now owns a dedicated child coroutine scope; closing the panel cancels enumeration, search and icon loads as a group.
- Icon cache now uses a small byte-oriented budget for bitmap drawables and is initialized safely across threads.
- Root availability is cached for 5 seconds to avoid repeated `su id` handshakes.
- Removed JitPack; Shizuku 13.1.5 is available from Maven Central.
- Added VietnameseSearch unit tests.
- Replaced the duplicate build workflow with `.github/workflows/main.yml`.
- The workflow supports both a normal Android repository and a single Android-project ZIP at repository root.
